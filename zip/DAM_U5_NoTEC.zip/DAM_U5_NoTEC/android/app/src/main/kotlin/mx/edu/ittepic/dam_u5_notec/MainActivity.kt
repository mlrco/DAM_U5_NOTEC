package mx.edu.ittepic.dam_u5_notec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
